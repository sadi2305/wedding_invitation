<?php 

$db_connect = mysqli_connect('localhost','root','','ms2');

?>